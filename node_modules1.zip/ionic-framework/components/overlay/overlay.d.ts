/**
 * @private
 */
export declare class OverlayNav {
    constructor();
}
