import { ElementRef, EventEmitter } from 'angular2/core';
import { Content } from '../content/content';
/**
 * @name Refresher
 * @description
 * Allows you to add pull-to-refresh to an Content component.
 * Place it as the first child of your Content or Scroll element.
 *
 * When refreshing is complete, call `refresher.complete()` from your controller.
 *
 *  @usage
 *  ```html
 *  <ion-content>
 *    <ion-refresher (start)="doStart($event)"
 *                   (refresh)="doRefresh($event)"
 *                   (pulling)="doPulling($event)">
 *    </ion-refresher>
 *
 *  </ion-content>

 *  ```
 *
 *  ```ts
 *  export class MyClass {
 *
 *    doRefresh(refresher) {
 *      console.log('Doing Refresh', refresher)
 *
 *      setTimeout(() => {
 *        refresher.complete();
 *        console.log("Complete");
 *      }, 5000);
 *    }
 *
 *    doStart(refresher) {
 *      console.log('Doing Start', refresher);
 *    }
 *
 *    doPulling(refresher) {
 *      console.log('Pulling', refresher);
 *    }
 *
 *  }
 *  ```
 *  @demo /docs/v2/demos/refresher/
 *
 */
export declare class Refresher {
    private _content;
    private _ele;
    private _touchMoveListener;
    private _touchEndListener;
    private _handleScrollListener;
    /**
     * @private
     */
    isActive: boolean;
    /**
     * @private
     */
    isDragging: boolean;
    /**
     * @private
     */
    isOverscrolling: boolean;
    /**
     * @private
     */
    dragOffset: number;
    /**
     * @private
     */
    lastOverscroll: number;
    /**
     * @private
     */
    ptrThreshold: number;
    /**
     * @private
     */
    activated: boolean;
    /**
     * @private
     */
    scrollTime: number;
    /**
     * @private
     */
    canOverscroll: boolean;
    /**
     * @private
     */
    startY: any;
    /**
     * @private
     */
    deltaY: any;
    /**
     * @private
     */
    scrollHost: any;
    /**
     * @private
     */
    scrollChild: any;
    /**
     * @private
     */
    showIcon: boolean;
    /**
     * @private
     */
    showSpinner: boolean;
    /**
     * @private
     */
    isRefreshing: boolean;
    /**
     * @private
     */
    isRefreshingTail: boolean;
    /**
     * @input {string} the icon you want to display when you begin to pull down
     */
    pullingIcon: string;
    /**
     * @input {string} the text you want to display when you begin to pull down
     */
    pullingText: string;
    /**
     * @input {string} the icon you want to display when performing a refresh
     */
    refreshingIcon: string;
    /**
     * @input {string} the text you want to display when performing a refresh
     */
    refreshingText: string;
    /**
     * @private
     */
    spinner: string;
    /**
     * @output {event} When you are pulling down
     */
    pulling: EventEmitter<Refresher>;
    /**
     * @output {event} When you are refreshing
     */
    refresh: EventEmitter<Refresher>;
    /**
     * @output {event} When you start pulling down
     */
    start: EventEmitter<Refresher>;
    constructor(_content: Content, _element: ElementRef);
    /**
     * @private
     */
    ngOnInit(): void;
    /**
     * @private
     */
    ngOnDestroy(): void;
    /**
     * @private
     * @param {TODO} val  TODO
     */
    overscroll(val: any): void;
    /**
     * @private
     * @param {TODO} target  TODO
     * @param {TODO} newScrollTop  TODO
     */
    nativescroll(target: any, newScrollTop: any): void;
    /**
     * @private
     * @param {TODO} enabled  TODO
     */
    setScrollLock(enabled: any): void;
    /**
     * @private
     */
    activate(): void;
    /**
     * @private
     */
    deactivate(): void;
    /**
     * @private
     */
    startRefresh(): void;
    /**
     * @private
     */
    show(): void;
    /**
     * @private
     */
    hide(): void;
    /**
     * @private
     */
    tail(): void;
    /**
     * @private
     */
    complete(): void;
    /**
     * @private
     * @param {TODO} Y  TODO
     * @param {TODO} duration  TODO
     * @param {Function} callback  TODO
     */
    scrollTo(Y: any, duration: any, callback?: any): void;
    /**
     * @private
     * TODO
     * @param {Event} e  TODO
     */
    _handleTouchMove(e: any): void;
    /**
     * @private
     * TODO
     * @param {Event} e  TODO
     */
    _handleTouchEnd(e: any): void;
    /**
     * @private
     * TODO
     * @param {Event} e  TODO
     */
    _handleScroll(e: any): void;
}
