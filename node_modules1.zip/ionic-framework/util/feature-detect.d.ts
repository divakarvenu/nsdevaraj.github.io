export declare class FeatureDetect {
    private _results;
    run(window: any, document: any): void;
    has(featureName: any): boolean;
    static add(name: any, fn: any): void;
}
