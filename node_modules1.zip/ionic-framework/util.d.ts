import * as domUtil from './util/dom';
export declare const dom: typeof domUtil;
export * from './util/util';
