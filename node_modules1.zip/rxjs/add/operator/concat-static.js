var Observable_1 = require('../../Observable');
var concat_static_1 = require('../../operator/concat-static');
Observable_1.Observable.concat = concat_static_1.concat;
//# sourceMappingURL=concat-static.js.map