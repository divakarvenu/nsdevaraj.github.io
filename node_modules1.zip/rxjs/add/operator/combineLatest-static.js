var Observable_1 = require('../../Observable');
var combineLatest_static_1 = require('../../operator/combineLatest-static');
Observable_1.Observable.combineLatest = combineLatest_static_1.combineLatest;
//# sourceMappingURL=combineLatest-static.js.map