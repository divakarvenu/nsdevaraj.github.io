var Observable_1 = require('../../Observable');
var elementAt_1 = require('../../operator/elementAt');
var observableProto = Observable_1.Observable.prototype;
observableProto.elementAt = elementAt_1.elementAt;
//# sourceMappingURL=elementAt.js.map