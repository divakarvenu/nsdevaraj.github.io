var Observable_1 = require('../../Observable');
var inspect_1 = require('../../operator/inspect');
Observable_1.Observable.prototype.inspect = inspect_1.inspect;
//# sourceMappingURL=inspect.js.map