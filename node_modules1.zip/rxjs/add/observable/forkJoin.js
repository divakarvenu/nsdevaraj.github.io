var Observable_1 = require('../../Observable');
var forkJoin_1 = require('../../observable/forkJoin');
Observable_1.Observable.forkJoin = forkJoin_1.ForkJoinObservable.create;
//# sourceMappingURL=forkJoin.js.map