var Observable_1 = require('../../Observable');
var fromEventPattern_1 = require('../../observable/fromEventPattern');
Observable_1.Observable.fromEventPattern = fromEventPattern_1.FromEventPatternObservable.create;
//# sourceMappingURL=fromEventPattern.js.map