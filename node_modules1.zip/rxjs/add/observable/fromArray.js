var Observable_1 = require('../../Observable');
var fromArray_1 = require('../../observable/fromArray');
Observable_1.Observable.fromArray = fromArray_1.ArrayObservable.create;
Observable_1.Observable.of = fromArray_1.ArrayObservable.of;
//# sourceMappingURL=fromArray.js.map