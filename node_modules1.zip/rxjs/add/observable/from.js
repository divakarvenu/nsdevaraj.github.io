var Observable_1 = require('../../Observable');
var from_1 = require('../../observable/from');
Observable_1.Observable.from = from_1.FromObservable.create;
//# sourceMappingURL=from.js.map