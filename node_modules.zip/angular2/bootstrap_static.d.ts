/**
 * See {@link bootstrap} for more information.
 * @deprecated
 */
export { bootstrapStatic } from 'angular2/platform/browser_static';
export { AngularEntrypoint } from 'angular2/src/core/angular_entrypoint';
