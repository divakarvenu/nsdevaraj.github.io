// TS does not have Observables
/**
 * This module exists in Dart, but not in Typescript. This exported symbol
 * is only here to help Typescript think this is a module.
 */
export var workaround_empty_observable_list_diff;
