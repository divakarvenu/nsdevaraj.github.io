import { enableProdMode } from 'angular2/core';
import { bootstrap } from 'angular2/bootstrap';
import { MyComponent } from 'my_component';
enableProdMode();
bootstrap(MyComponent);
// #enddocregion
