// Index to be used if Http is ever configured as a standalone npm package.
// require('reflect-metadata');
// require('es6-shim');
// import {HTTP_PROVIDERS, JSONP_PROVIDERS, Http, Jsonp} from './http';
// import {Injector} from 'angular2/core';
// export * from './http';
// /**
//  * TODO(jeffbcross): export each as their own top-level file, to require as:
//  * require('angular2/http'); require('http/jsonp');
//  */
// export var http = Injector.resolveAndCreate([HTTP_PROVIDERS]).get(Http);
// export var jsonp = Injector.resolveAndCreate([JSONP_PROVIDERS]).get(Jsonp);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhbmd1bGFyMi9zcmMvaHR0cC9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSwyRUFBMkU7QUFDM0UsK0JBQStCO0FBQy9CLHVCQUF1QjtBQUN2Qix1RUFBdUU7QUFDdkUsMENBQTBDO0FBQzFDLDBCQUEwQjtBQUUxQixNQUFNO0FBQ04sK0VBQStFO0FBQy9FLHNEQUFzRDtBQUN0RCxNQUFNO0FBQ04sMkVBQTJFO0FBQzNFLDhFQUE4RSIsInNvdXJjZXNDb250ZW50IjpbIi8vIEluZGV4IHRvIGJlIHVzZWQgaWYgSHR0cCBpcyBldmVyIGNvbmZpZ3VyZWQgYXMgYSBzdGFuZGFsb25lIG5wbSBwYWNrYWdlLlxuLy8gcmVxdWlyZSgncmVmbGVjdC1tZXRhZGF0YScpO1xuLy8gcmVxdWlyZSgnZXM2LXNoaW0nKTtcbi8vIGltcG9ydCB7SFRUUF9QUk9WSURFUlMsIEpTT05QX1BST1ZJREVSUywgSHR0cCwgSnNvbnB9IGZyb20gJy4vaHR0cCc7XG4vLyBpbXBvcnQge0luamVjdG9yfSBmcm9tICdhbmd1bGFyMi9jb3JlJztcbi8vIGV4cG9ydCAqIGZyb20gJy4vaHR0cCc7XG5cbi8vIC8qKlxuLy8gICogVE9ETyhqZWZmYmNyb3NzKTogZXhwb3J0IGVhY2ggYXMgdGhlaXIgb3duIHRvcC1sZXZlbCBmaWxlLCB0byByZXF1aXJlIGFzOlxuLy8gICogcmVxdWlyZSgnYW5ndWxhcjIvaHR0cCcpOyByZXF1aXJlKCdodHRwL2pzb25wJyk7XG4vLyAgKi9cbi8vIGV4cG9ydCB2YXIgaHR0cCA9IEluamVjdG9yLnJlc29sdmVBbmRDcmVhdGUoW0hUVFBfUFJPVklERVJTXSkuZ2V0KEh0dHApO1xuLy8gZXhwb3J0IHZhciBqc29ucCA9IEluamVjdG9yLnJlc29sdmVBbmRDcmVhdGUoW0pTT05QX1BST1ZJREVSU10pLmdldChKc29ucCk7XG4iXX0=